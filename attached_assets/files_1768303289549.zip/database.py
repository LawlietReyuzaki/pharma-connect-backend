"""
Medication Database Module
Local SQLite database for medication storage and retrieval
"""

import os
import json
import sqlite3
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from contextlib import contextmanager
import re


@dataclass
class Medication:
    """Medication data model"""
    id: int
    name: str
    price: float
    manufacturer: str
    ingredients: str
    form: str
    size: str
    prescription_required: bool
    description: str
    image: str  # Local path only!
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class MedicationDatabase:
    """
    Internal Medication Database
    
    RULES (NON-NEGOTIABLE):
    1. DB lookup ALWAYS happens before web crawling
    2. Images MUST come ONLY from local /static/images/ folder
    3. Never return external image URLs
    """
    
    DB_PATH = "data/medications.db"
    IMAGES_DIR = "static/images"
    
    def __init__(self):
        self.db_path = self.DB_PATH
        self._ensure_dirs()
    
    def _ensure_dirs(self):
        """Ensure required directories exist"""
        Path("data").mkdir(exist_ok=True)
        Path(self.IMAGES_DIR).mkdir(parents=True, exist_ok=True)
    
    @contextmanager
    def _get_connection(self):
        """Context manager for database connections"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
        finally:
            conn.close()
    
    def initialize(self):
        """Initialize database with schema and sample data"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Create medications table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS medications (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL UNIQUE,
                    price REAL DEFAULT 0.0,
                    manufacturer TEXT,
                    ingredients TEXT,
                    form TEXT,
                    size TEXT,
                    prescription_required INTEGER DEFAULT 0,
                    description TEXT,
                    image TEXT,
                    synonyms TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Create index for fast searching
            cursor.execute('''
                CREATE INDEX IF NOT EXISTS idx_medication_name 
                ON medications(name)
            ''')
            
            cursor.execute('''
                CREATE INDEX IF NOT EXISTS idx_medication_ingredients 
                ON medications(ingredients)
            ''')
            
            conn.commit()
            
            # Insert sample data if empty
            cursor.execute("SELECT COUNT(*) FROM medications")
            if cursor.fetchone()[0] == 0:
                self._insert_sample_data(conn)
    
    def _insert_sample_data(self, conn):
        """Insert sample medications for testing"""
        sample_medications = [
            {
                "name": "panadol",
                "price": 5.99,
                "manufacturer": "GSK",
                "ingredients": "paracetamol",
                "form": "tablet",
                "size": "500mg",
                "prescription_required": False,
                "description": "Pain reliever and fever reducer containing paracetamol (acetaminophen). Used for mild to moderate pain and fever.",
                "image": "panadol.jpg",
                "synonyms": "panadol extra,panadol advance,acetaminophen"
            },
            {
                "name": "amoxicillin",
                "price": 12.50,
                "manufacturer": "Various",
                "ingredients": "amoxicillin trihydrate",
                "form": "capsule",
                "size": "500mg",
                "prescription_required": True,
                "description": "Broad-spectrum antibiotic used to treat bacterial infections including respiratory, urinary, and skin infections.",
                "image": "amoxicillin.png",
                "synonyms": "amoxil,trimox"
            },
            {
                "name": "ibuprofen",
                "price": 7.99,
                "manufacturer": "Various",
                "ingredients": "ibuprofen",
                "form": "tablet",
                "size": "400mg",
                "prescription_required": False,
                "description": "Non-steroidal anti-inflammatory drug (NSAID) used for pain, fever, and inflammation.",
                "image": "ibuprofen.jpg",
                "synonyms": "advil,motrin,brufen"
            },
            {
                "name": "cetirizine",
                "price": 8.50,
                "manufacturer": "Various",
                "ingredients": "cetirizine hydrochloride",
                "form": "tablet",
                "size": "10mg",
                "prescription_required": False,
                "description": "Antihistamine used to relieve allergy symptoms such as sneezing, runny nose, and itchy eyes.",
                "image": "cetirizine.jpg",
                "synonyms": "zyrtec,reactine"
            },
            {
                "name": "omeprazole",
                "price": 15.00,
                "manufacturer": "Various",
                "ingredients": "omeprazole",
                "form": "capsule",
                "size": "20mg",
                "prescription_required": False,
                "description": "Proton pump inhibitor (PPI) used to treat acid reflux, GERD, and stomach ulcers.",
                "image": "omeprazole.jpg",
                "synonyms": "prilosec,losec"
            },
            {
                "name": "metformin",
                "price": 10.00,
                "manufacturer": "Various",
                "ingredients": "metformin hydrochloride",
                "form": "tablet",
                "size": "500mg",
                "prescription_required": True,
                "description": "Oral diabetes medication used to control blood sugar levels in type 2 diabetes.",
                "image": "metformin.jpg",
                "synonyms": "glucophage,fortamet"
            },
            {
                "name": "aspirin",
                "price": 4.50,
                "manufacturer": "Bayer",
                "ingredients": "acetylsalicylic acid",
                "form": "tablet",
                "size": "325mg",
                "prescription_required": False,
                "description": "Pain reliever, fever reducer, and anti-inflammatory. Also used for heart attack prevention.",
                "image": "aspirin.jpg",
                "synonyms": "bayer aspirin,ecotrin"
            },
            {
                "name": "azithromycin",
                "price": 18.00,
                "manufacturer": "Pfizer",
                "ingredients": "azithromycin dihydrate",
                "form": "tablet",
                "size": "250mg",
                "prescription_required": True,
                "description": "Macrolide antibiotic used to treat bacterial infections including respiratory and skin infections.",
                "image": "azithromycin.jpg",
                "synonyms": "zithromax,z-pack"
            },
            {
                "name": "loratadine",
                "price": 9.00,
                "manufacturer": "Various",
                "ingredients": "loratadine",
                "form": "tablet",
                "size": "10mg",
                "prescription_required": False,
                "description": "Non-drowsy antihistamine for allergy relief including hay fever and hives.",
                "image": "loratadine.jpg",
                "synonyms": "claritin,alavert"
            },
            {
                "name": "diclofenac",
                "price": 11.00,
                "manufacturer": "Novartis",
                "ingredients": "diclofenac sodium",
                "form": "tablet",
                "size": "50mg",
                "prescription_required": True,
                "description": "NSAID used for pain and inflammation in arthritis, sprains, and other conditions.",
                "image": "diclofenac.jpg",
                "synonyms": "voltaren,cataflam"
            }
        ]
        
        cursor = conn.cursor()
        for med in sample_medications:
            cursor.execute('''
                INSERT INTO medications 
                (name, price, manufacturer, ingredients, form, size, 
                 prescription_required, description, image, synonyms)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                med["name"], med["price"], med["manufacturer"],
                med["ingredients"], med["form"], med["size"],
                med["prescription_required"], med["description"],
                med["image"], med["synonyms"]
            ))
        
        conn.commit()
        print(f"✅ Inserted {len(sample_medications)} sample medications")
    
    def search(self, query: str, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Search medications with multiple matching strategies
        
        Strategy Order:
        1. Exact name match
        2. Partial name match
        3. Ingredient match
        4. Synonym match
        5. Fuzzy match
        """
        query = query.lower().strip()
        results = []
        
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # 1. Exact match
            cursor.execute(
                "SELECT * FROM medications WHERE LOWER(name) = ?",
                (query,)
            )
            exact = cursor.fetchall()
            if exact:
                return [self._row_to_dict(r) for r in exact]
            
            # 2. Partial name match (starts with)
            cursor.execute(
                "SELECT * FROM medications WHERE LOWER(name) LIKE ? LIMIT ?",
                (f"{query}%", limit)
            )
            results.extend(cursor.fetchall())
            
            # 3. Contains in name
            if len(results) < limit:
                cursor.execute(
                    "SELECT * FROM medications WHERE LOWER(name) LIKE ? AND LOWER(name) NOT LIKE ? LIMIT ?",
                    (f"%{query}%", f"{query}%", limit - len(results))
                )
                results.extend(cursor.fetchall())
            
            # 4. Ingredient match
            if len(results) < limit:
                cursor.execute(
                    "SELECT * FROM medications WHERE LOWER(ingredients) LIKE ? LIMIT ?",
                    (f"%{query}%", limit - len(results))
                )
                results.extend(cursor.fetchall())
            
            # 5. Synonym match
            if len(results) < limit:
                cursor.execute(
                    "SELECT * FROM medications WHERE LOWER(synonyms) LIKE ? LIMIT ?",
                    (f"%{query}%", limit - len(results))
                )
                results.extend(cursor.fetchall())
        
        # Remove duplicates while preserving order
        seen = set()
        unique_results = []
        for r in results:
            if r['id'] not in seen:
                seen.add(r['id'])
                unique_results.append(self._row_to_dict(r))
        
        return unique_results[:limit]
    
    def search_by_ingredient(self, ingredient: str) -> List[Dict[str, Any]]:
        """Search medications by ingredient"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT * FROM medications WHERE LOWER(ingredients) LIKE ?",
                (f"%{ingredient.lower()}%",)
            )
            return [self._row_to_dict(r) for r in cursor.fetchall()]
    
    def get_by_id(self, med_id: int) -> Optional[Dict[str, Any]]:
        """Get medication by ID"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM medications WHERE id = ?", (med_id,))
            row = cursor.fetchone()
            return self._row_to_dict(row) if row else None
    
    def get_all(self) -> List[Dict[str, Any]]:
        """Get all medications"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM medications ORDER BY name")
            return [self._row_to_dict(r) for r in cursor.fetchall()]
    
    def count(self) -> int:
        """Get total medication count"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM medications")
            return cursor.fetchone()[0]
    
    def add(self, medication: Dict[str, Any]) -> int:
        """Add new medication"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO medications 
                (name, price, manufacturer, ingredients, form, size,
                 prescription_required, description, image, synonyms)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                medication.get("name", "").lower(),
                medication.get("price", 0.0),
                medication.get("manufacturer", ""),
                medication.get("ingredients", ""),
                medication.get("form", ""),
                medication.get("size", ""),
                medication.get("prescription_required", False),
                medication.get("description", ""),
                medication.get("image", ""),
                medication.get("synonyms", "")
            ))
            conn.commit()
            return cursor.lastrowid
    
    def _row_to_dict(self, row: sqlite3.Row) -> Dict[str, Any]:
        """Convert database row to dictionary with validated image path"""
        if row is None:
            return {}
        
        data = dict(row)
        
        # Validate and set image path
        if data.get("image"):
            data["image"] = self._validate_image_path(data["image"])
        else:
            data["image"] = None
        
        return data
    
    def _validate_image_path(self, image_name: str) -> Optional[str]:
        """
        Validate image exists in local images folder
        
        RULE: Images MUST come ONLY from local /static/images/ folder
        """
        if not image_name:
            return None
        
        # Remove any path prefix - only use filename
        image_name = os.path.basename(image_name)
        
        # Check for valid extensions
        valid_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.webp'}
        ext = os.path.splitext(image_name)[1].lower()
        
        if ext not in valid_extensions:
            return None
        
        # Check if file exists
        image_path = os.path.join(self.IMAGES_DIR, image_name)
        if os.path.exists(image_path):
            return f"/static/images/{image_name}"
        
        return None
