# 🚀 QUICK START CHECKLIST FOR REPLIT

## Copy these files to your Replit project:

```
☐ requirements.txt          → Root folder
☐ main.py                   → Root folder  
☐ agent/__init__.py         → agent/ folder
☐ agent/gemini_client.py    → agent/ folder
☐ agent/query_classifier.py → agent/ folder
☐ agent/database.py         → agent/ folder
☐ agent/wikipedia_crawler.py→ agent/ folder
☐ agent/image_validator.py  → agent/ folder
☐ agent/rag_engine.py       → agent/ folder
☐ templates/index.html      → templates/ folder
```

## Quick Setup Commands (Run in Replit Shell):

```bash
# 1. Create folders
mkdir -p agent static/images templates data

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set your Gemini API key (in Replit Secrets)
# Key: GEMINI_API_KEY
# Value: your_api_key_here

# 4. Run the app
python main.py
```

## Test it works:

```bash
# Health check
curl http://localhost:8000/health

# Test query
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"query": "panadol", "include_wiki": false}'
```

## 🔑 KEY SAFETY RULES (CANNOT BE OVERRIDDEN):

1. ✅ Database lookup ALWAYS happens FIRST
2. ✅ Images ONLY from local /static/images/ folder  
3. ✅ Wikipedia fetches TEXT ONLY (no images ever)
4. ✅ Gemini validates all medical logic
5. ❌ NEVER show external/Wikipedia images
6. ❌ NEVER hallucinate medications
7. ❌ NEVER auto-crawl without DB check first
