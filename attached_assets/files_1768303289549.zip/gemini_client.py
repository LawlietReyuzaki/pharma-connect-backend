"""
Gemini LLM Client
Handles all LLM interactions for query understanding, classification, and medical mapping
"""

import os
import json
import re
from typing import Dict, Optional, List, Any
import google.generativeai as genai


class GeminiClient:
    """
    Gemini API Client for Medical Query Processing
    
    Responsibilities:
    - Query understanding
    - Keyword extraction
    - Intent classification
    - Disease → medicine mapping
    """
    
    def __init__(self):
        self.api_key = os.environ.get("GEMINI_API_KEY")
        self._connected = False
        
        if self.api_key:
            try:
                genai.configure(api_key=self.api_key)
                self.model = genai.GenerativeModel('gemini-1.5-flash')
                self._connected = True
                print("✅ Gemini API connected")
            except Exception as e:
                print(f"⚠️ Gemini connection failed: {e}")
                self._connected = False
        else:
            print("⚠️ GEMINI_API_KEY not set - using fallback mode")
    
    def is_connected(self) -> bool:
        return self._connected
    
    async def extract_medical_keyword(self, query: str) -> Dict[str, Any]:
        """
        Extract clean medical subject from user query
        
        Example:
            Input: "what are main symptoms of disease syphilis"
            Output: {"keyword": "syphilis", "query_type": "disease"}
        """
        prompt = f"""You are a medical query parser. Extract the PRIMARY medical subject from this query.

Query: "{query}"

Rules:
1. Extract ONLY the main medical term (disease name, medication name, or symptom)
2. Remove filler words like "what", "are", "main", "symptoms", "of", "disease"
3. Classify the query type

Respond ONLY in this JSON format:
{{
    "extracted_keyword": "<single medical term>",
    "query_type": "<medication|disease|symptom|general>",
    "intent": "<lookup|explanation|treatment|side_effects>",
    "confidence": <0.0-1.0>
}}

Examples:
- "what are main symptoms of disease syphilis" → {{"extracted_keyword": "syphilis", "query_type": "disease", "intent": "explanation", "confidence": 0.95}}
- "Panadol 500mg dosage" → {{"extracted_keyword": "panadol", "query_type": "medication", "intent": "lookup", "confidence": 0.98}}
- "medicine for fever" → {{"extracted_keyword": "fever", "query_type": "symptom", "intent": "treatment", "confidence": 0.9}}
"""
        
        if not self._connected:
            return self._fallback_extraction(query)
        
        try:
            response = self.model.generate_content(prompt)
            text = response.text.strip()
            
            # Extract JSON from response
            json_match = re.search(r'\{[^}]+\}', text, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
            
            return self._fallback_extraction(query)
            
        except Exception as e:
            print(f"Gemini extraction error: {e}")
            return self._fallback_extraction(query)
    
    async def map_disease_to_medications(self, disease: str) -> List[str]:
        """
        Map disease/symptom to relevant medication ingredients
        
        Example:
            Input: "fever"
            Output: ["paracetamol", "ibuprofen", "aspirin"]
        """
        prompt = f"""You are a medical assistant. Map this condition to common medication INGREDIENTS (not brand names).

Condition: "{disease}"

Rules:
1. List only generic medication ingredients
2. Maximum 5 ingredients
3. Order by relevance/common usage
4. Only include widely accepted treatments

Respond ONLY as JSON array:
["ingredient1", "ingredient2", "ingredient3"]

Examples:
- "fever" → ["paracetamol", "ibuprofen", "aspirin"]
- "bacterial infection" → ["amoxicillin", "azithromycin", "ciprofloxacin"]
- "headache" → ["paracetamol", "ibuprofen", "aspirin"]
"""
        
        if not self._connected:
            return self._fallback_disease_mapping(disease)
        
        try:
            response = self.model.generate_content(prompt)
            text = response.text.strip()
            
            # Extract JSON array
            json_match = re.search(r'\[[^\]]+\]', text)
            if json_match:
                return json.loads(json_match.group())
            
            return self._fallback_disease_mapping(disease)
            
        except Exception as e:
            print(f"Gemini mapping error: {e}")
            return self._fallback_disease_mapping(disease)
    
    async def generate_wiki_query(self, keyword: str, query_type: str) -> str:
        """
        Generate precise Wikipedia search query
        
        Rules:
        ✅ Allowed: "Syphilis disease symptoms", "Paracetamol drug usage"
        ❌ Blocked: "fever", "medicine images", "human anatomy"
        """
        prompt = f"""Generate a precise Wikipedia search query for medical information.

Keyword: "{keyword}"
Type: "{query_type}"

Rules:
1. Create a specific, medical search query
2. Include the type context (disease, drug, symptom)
3. Focus on medical/clinical information
4. NEVER include: "images", "pictures", "photos", "anatomy", "diagram"

Respond with ONLY the search query string, nothing else.

Examples:
- keyword="syphilis", type="disease" → "Syphilis sexually transmitted infection symptoms treatment"
- keyword="paracetamol", type="medication" → "Paracetamol acetaminophen drug pharmacology"
- keyword="diabetes", type="disease" → "Diabetes mellitus medical condition symptoms"
"""
        
        if not self._connected:
            return f"{keyword} {query_type} medical information"
        
        try:
            response = self.model.generate_content(prompt)
            query = response.text.strip().strip('"\'')
            
            # Safety check - block forbidden terms
            forbidden = ['image', 'picture', 'photo', 'anatomy', 'diagram', 'structure']
            if any(term in query.lower() for term in forbidden):
                return f"{keyword} {query_type} medical information"
            
            return query
            
        except Exception as e:
            print(f"Gemini query generation error: {e}")
            return f"{keyword} {query_type} medical information"
    
    async def summarize_wiki_content(self, content: str, keyword: str) -> str:
        """
        Summarize Wikipedia content focusing on medical relevance
        
        Extracts ONLY:
        - Indications
        - Usage
        - Side effects
        """
        prompt = f"""Summarize this medical Wikipedia content about "{keyword}".

Content:
{content[:4000]}

Rules:
1. Focus ONLY on: indications, usage, side effects, symptoms, treatment
2. Remove any image references or descriptions
3. Keep it concise (max 500 words)
4. Use bullet points for clarity
5. Include medical warnings if present

Format your response as:
## Overview
<brief overview>

## Key Information
- <point 1>
- <point 2>

## Warnings/Side Effects
- <if applicable>
"""
        
        if not self._connected:
            # Return truncated content
            return content[:1000] + "..." if len(content) > 1000 else content
        
        try:
            response = self.model.generate_content(prompt)
            return response.text.strip()
        except Exception as e:
            print(f"Gemini summarization error: {e}")
            return content[:1000] + "..." if len(content) > 1000 else content
    
    def _fallback_extraction(self, query: str) -> Dict[str, Any]:
        """Fallback keyword extraction without LLM"""
        # Remove common filler words
        stop_words = {
            'what', 'are', 'is', 'the', 'main', 'symptoms', 'of', 'for',
            'disease', 'medicine', 'drug', 'tablet', 'capsule', 'how',
            'does', 'work', 'can', 'i', 'take', 'treat', 'treatment'
        }
        
        words = query.lower().split()
        keywords = [w for w in words if w not in stop_words and len(w) > 2]
        
        # Detect query type
        query_type = "general"
        if any(w in query.lower() for w in ['symptom', 'disease', 'infection', 'condition']):
            query_type = "disease"
        elif any(w in query.lower() for w in ['mg', 'ml', 'tablet', 'capsule', 'dose']):
            query_type = "medication"
        elif any(w in query.lower() for w in ['pain', 'fever', 'cough', 'cold']):
            query_type = "symptom"
        
        return {
            "extracted_keyword": keywords[0] if keywords else query.split()[0],
            "query_type": query_type,
            "intent": "lookup",
            "confidence": 0.6
        }
    
    def _fallback_disease_mapping(self, disease: str) -> List[str]:
        """Fallback disease to medication mapping"""
        mappings = {
            "fever": ["paracetamol", "ibuprofen"],
            "pain": ["paracetamol", "ibuprofen", "aspirin"],
            "headache": ["paracetamol", "ibuprofen"],
            "infection": ["amoxicillin", "azithromycin"],
            "cold": ["paracetamol", "phenylephrine"],
            "cough": ["dextromethorphan", "guaifenesin"],
            "allergy": ["cetirizine", "loratadine"],
            "inflammation": ["ibuprofen", "diclofenac"],
        }
        
        disease_lower = disease.lower()
        for key, meds in mappings.items():
            if key in disease_lower:
                return meds
        
        return ["paracetamol"]  # Safe default
