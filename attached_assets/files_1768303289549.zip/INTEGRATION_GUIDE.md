# 🏥 Medical RAG Agent - Integration Instructions for Replit

## Overview
This guide helps you integrate the intelligent medical-safe RAG system into your existing Replit project.

---

## 🔧 STEP 1: Install Required Dependencies

Add these to your `requirements.txt` or run in Replit Shell:

```bash
pip install google-generativeai aiohttp fastapi uvicorn pydantic
```

Or add to `pyproject.toml`:
```toml
[tool.poetry.dependencies]
google-generativeai = "^0.3.0"
aiohttp = "^3.9.0"
fastapi = "^0.109.0"
uvicorn = "^0.27.0"
pydantic = "^2.5.0"
```

---

## 🔑 STEP 2: Set Up Environment Variables

In Replit, go to **Secrets** (lock icon) and add:

```
GEMINI_API_KEY=your_gemini_api_key_here
```

---

## 📁 STEP 3: Project Structure

Ensure your project has this structure:

```
your-project/
├── main.py                    # Your main FastAPI app
├── agent/
│   ├── __init__.py
│   ├── gemini_client.py       # Gemini LLM integration
│   ├── query_classifier.py    # Query classification
│   ├── database.py            # Medication database
│   ├── wikipedia_crawler.py   # Safe Wikipedia crawler
│   ├── image_validator.py     # Image validation middleware
│   └── rag_engine.py          # Main RAG orchestrator
├── static/
│   └── images/                # LOCAL medication images ONLY
│       ├── panadol.jpg
│       ├── amoxicillin.png
│       └── ...
├── templates/
│   └── index.html
├── data/
│   └── medications.db         # SQLite database
└── requirements.txt
```

---

## 📝 STEP 4: Core Code Integration

### 4.1 Create `agent/__init__.py`

```python
from .gemini_client import GeminiClient
from .query_classifier import QueryClassifier, QueryType, QueryIntent
from .database import MedicationDatabase
from .wikipedia_crawler import WikipediaCrawler
from .image_validator import ImageValidator
from .rag_engine import MedicalRAGEngine

__all__ = [
    'GeminiClient', 'QueryClassifier', 'QueryType', 'QueryIntent',
    'MedicationDatabase', 'WikipediaCrawler', 'ImageValidator', 'MedicalRAGEngine'
]
```

### 4.2 Create `agent/gemini_client.py`

```python
"""
Gemini LLM Client - Handles all LLM interactions
"""
import os
import json
import re
from typing import Dict, List, Any
import google.generativeai as genai


class GeminiClient:
    def __init__(self):
        self.api_key = os.environ.get("GEMINI_API_KEY")
        self._connected = False
        
        if self.api_key:
            try:
                genai.configure(api_key=self.api_key)
                self.model = genai.GenerativeModel('gemini-1.5-flash')
                self._connected = True
            except Exception as e:
                print(f"Gemini connection failed: {e}")
    
    def is_connected(self) -> bool:
        return self._connected
    
    async def extract_medical_keyword(self, query: str) -> Dict[str, Any]:
        """Extract clean medical subject from user query"""
        prompt = f"""You are a medical query parser. Extract the PRIMARY medical subject.

Query: "{query}"

Respond ONLY in JSON:
{{
    "extracted_keyword": "<single medical term>",
    "query_type": "<medication|disease|symptom|general>",
    "intent": "<lookup|explanation|treatment|side_effects>",
    "confidence": <0.0-1.0>
}}

Examples:
- "what are main symptoms of disease syphilis" → {{"extracted_keyword": "syphilis", "query_type": "disease", "intent": "explanation", "confidence": 0.95}}
- "Panadol 500mg" → {{"extracted_keyword": "panadol", "query_type": "medication", "intent": "lookup", "confidence": 0.98}}
"""
        
        if not self._connected:
            return self._fallback_extraction(query)
        
        try:
            response = self.model.generate_content(prompt)
            json_match = re.search(r'\{[^}]+\}', response.text.strip(), re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
            return self._fallback_extraction(query)
        except Exception as e:
            return self._fallback_extraction(query)
    
    async def map_disease_to_medications(self, disease: str) -> List[str]:
        """Map disease/symptom to medication ingredients"""
        prompt = f"""Map this condition to common medication INGREDIENTS (not brand names).

Condition: "{disease}"

Respond ONLY as JSON array: ["ingredient1", "ingredient2", "ingredient3"]
"""
        
        if not self._connected:
            return self._fallback_disease_mapping(disease)
        
        try:
            response = self.model.generate_content(prompt)
            json_match = re.search(r'\[[^\]]+\]', response.text.strip())
            if json_match:
                return json.loads(json_match.group())
            return self._fallback_disease_mapping(disease)
        except:
            return self._fallback_disease_mapping(disease)
    
    async def generate_wiki_query(self, keyword: str, query_type: str) -> str:
        """Generate safe Wikipedia search query"""
        # Block forbidden terms
        forbidden = ['image', 'picture', 'photo', 'anatomy', 'diagram']
        
        if not self._connected:
            return f"{keyword} {query_type} medical information"
        
        try:
            prompt = f"""Generate a Wikipedia search query for medical info.
Keyword: "{keyword}", Type: "{query_type}"
NEVER include: images, pictures, anatomy, diagrams
Respond with ONLY the search query."""
            
            response = self.model.generate_content(prompt)
            query = response.text.strip().strip('"\'')
            
            if any(term in query.lower() for term in forbidden):
                return f"{keyword} {query_type} medical information"
            return query
        except:
            return f"{keyword} {query_type} medical information"
    
    async def summarize_wiki_content(self, content: str, keyword: str) -> str:
        """Summarize Wikipedia content for medical relevance"""
        if not self._connected:
            return content[:1000] + "..." if len(content) > 1000 else content
        
        try:
            prompt = f"""Summarize this medical content about "{keyword}".
Focus ONLY on: indications, usage, side effects, symptoms, treatment.
Remove any image references. Max 500 words.

Content: {content[:4000]}"""
            
            response = self.model.generate_content(prompt)
            return response.text.strip()
        except:
            return content[:1000]
    
    def _fallback_extraction(self, query: str) -> Dict[str, Any]:
        """Fallback without LLM"""
        stop_words = {'what', 'are', 'is', 'the', 'main', 'symptoms', 'of', 'for', 'disease', 'medicine'}
        words = [w for w in query.lower().split() if w not in stop_words and len(w) > 2]
        
        query_type = "general"
        if any(w in query.lower() for w in ['symptom', 'disease', 'infection']):
            query_type = "disease"
        elif any(w in query.lower() for w in ['mg', 'ml', 'tablet', 'capsule']):
            query_type = "medication"
        
        return {
            "extracted_keyword": words[0] if words else query.split()[0],
            "query_type": query_type,
            "intent": "lookup",
            "confidence": 0.6
        }
    
    def _fallback_disease_mapping(self, disease: str) -> List[str]:
        """Fallback disease mapping"""
        mappings = {
            "fever": ["paracetamol", "ibuprofen"],
            "pain": ["paracetamol", "ibuprofen", "aspirin"],
            "headache": ["paracetamol", "ibuprofen"],
            "infection": ["amoxicillin", "azithromycin"],
            "cold": ["paracetamol", "phenylephrine"],
            "cough": ["dextromethorphan", "guaifenesin"],
            "allergy": ["cetirizine", "loratadine"],
        }
        
        for key, meds in mappings.items():
            if key in disease.lower():
                return meds
        return ["paracetamol"]
```

### 4.3 Create `agent/query_classifier.py`

```python
"""
Query Classifier - Classifies medical queries using Gemini
"""
import re
from typing import Dict, Any
from dataclasses import dataclass
from enum import Enum


class QueryType(Enum):
    MEDICATION = "medication"
    DISEASE = "disease"
    SYMPTOM = "symptom"
    GENERAL = "general"


class QueryIntent(Enum):
    LOOKUP = "lookup"
    EXPLANATION = "explanation"
    TREATMENT = "treatment"
    SIDE_EFFECTS = "side_effects"


@dataclass
class ClassifiedQuery:
    original_query: str
    extracted_keyword: str
    query_type: QueryType
    intent: QueryIntent
    confidence: float
    normalized_keyword: str
    requires_wiki: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "original_query": self.original_query,
            "extracted_keyword": self.extracted_keyword,
            "query_type": self.query_type.value,
            "intent": self.intent.value,
            "confidence": self.confidence,
            "normalized_keyword": self.normalized_keyword,
            "requires_wiki": self.requires_wiki
        }


class QueryClassifier:
    def __init__(self, gemini_client):
        self.gemini = gemini_client
    
    async def classify(self, query: str) -> ClassifiedQuery:
        """Main classification method"""
        extraction = await self.gemini.extract_medical_keyword(query)
        
        keyword = extraction.get("extracted_keyword", "")
        query_type_str = extraction.get("query_type", "general")
        intent_str = extraction.get("intent", "lookup")
        confidence = extraction.get("confidence", 0.5)
        
        normalized = self.normalize_medication_name(keyword)
        query_type = self._map_query_type(query_type_str)
        intent = self._map_intent(intent_str)
        requires_wiki = self._should_fetch_wiki(query_type, intent, query)
        
        return ClassifiedQuery(
            original_query=query,
            extracted_keyword=keyword,
            query_type=query_type,
            intent=intent,
            confidence=confidence,
            normalized_keyword=normalized,
            requires_wiki=requires_wiki
        )
    
    def normalize_medication_name(self, name: str) -> str:
        """Normalize: lowercase, remove mg/ml, remove form words"""
        if not name:
            return ""
        
        normalized = name.lower().strip()
        normalized = re.sub(r'\d+\s*(mg|ml|mcg|g|iu|%)', '', normalized)
        
        for word in ['tablet', 'capsule', 'syrup', 'injection', 'cream']:
            normalized = normalized.replace(word, '')
        
        normalized = re.sub(r'[^\w\s-]', '', normalized)
        return ' '.join(normalized.split()).strip()
    
    def _map_query_type(self, type_str: str) -> QueryType:
        mapping = {
            "medication": QueryType.MEDICATION,
            "disease": QueryType.DISEASE,
            "symptom": QueryType.SYMPTOM,
        }
        return mapping.get(type_str.lower(), QueryType.GENERAL)
    
    def _map_intent(self, intent_str: str) -> QueryIntent:
        mapping = {
            "lookup": QueryIntent.LOOKUP,
            "explanation": QueryIntent.EXPLANATION,
            "treatment": QueryIntent.TREATMENT,
            "side_effects": QueryIntent.SIDE_EFFECTS,
        }
        return mapping.get(intent_str.lower(), QueryIntent.LOOKUP)
    
    def _should_fetch_wiki(self, query_type: QueryType, intent: QueryIntent, query: str) -> bool:
        if query_type in [QueryType.DISEASE, QueryType.SYMPTOM]:
            if intent in [QueryIntent.EXPLANATION, QueryIntent.SIDE_EFFECTS]:
                return True
        
        keywords = ['what is', 'explain', 'symptoms of', 'side effects']
        return any(kw in query.lower() for kw in keywords)
    
    def validate_medical_term(self, term: str) -> bool:
        """Validate term is medical, not injection"""
        blocked = [r'http[s]?://', r'<.*?>', r'SELECT|INSERT|DELETE']
        for pattern in blocked:
            if re.search(pattern, term, re.IGNORECASE):
                return False
        return 2 < len(term) < 100
```

### 4.4 Create `agent/image_validator.py`

```python
"""
Image Validator - LOCAL IMAGES ONLY
"""
import os
import re
from pathlib import Path
from typing import Optional, Set
from dataclasses import dataclass


@dataclass
class ImageValidationResult:
    is_valid: bool
    path: Optional[str]
    reason: str


class ImageValidator:
    """
    RULES (NON-NEGOTIABLE):
    1. Images ONLY from /static/images/
    2. Valid extensions: jpg, jpeg, png, gif, webp
    3. FORBIDDEN: Wikipedia images, disease images, external URLs
    """
    
    IMAGES_DIR = "static/images"
    VALID_EXTENSIONS: Set[str] = {'.jpg', '.jpeg', '.png', '.gif', '.webp'}
    
    FORBIDDEN_PATTERNS = [
        r'wikipedia', r'wikimedia', r'anatomy', r'diagram',
        r'disease', r'symptom', r'http[s]?://', r'www\.'
    ]
    
    def __init__(self):
        Path(self.IMAGES_DIR).mkdir(parents=True, exist_ok=True)
        self._cache: dict = {}
    
    def validate(self, medication_name: str) -> ImageValidationResult:
        """Validate and get image path for medication"""
        if not medication_name:
            return ImageValidationResult(False, None, "No name provided")
        
        normalized = self._normalize_name(medication_name)
        
        if normalized in self._cache:
            path = self._cache[normalized]
            if path:
                return ImageValidationResult(True, path, "Cached")
            return ImageValidationResult(False, None, "Not found (cached)")
        
        image_path = self._find_image(normalized)
        self._cache[normalized] = image_path
        
        if image_path:
            return ImageValidationResult(True, image_path, "Found")
        return ImageValidationResult(False, None, f"No image for: {normalized}")
    
    def validate_path(self, path: str) -> ImageValidationResult:
        """Validate a given image path"""
        if not path:
            return ImageValidationResult(False, None, "Empty path")
        
        # Block forbidden patterns
        for pattern in self.FORBIDDEN_PATTERNS:
            if re.search(pattern, path.lower()):
                return ImageValidationResult(False, None, f"Blocked: {pattern}")
        
        # Must be local
        if path.startswith('http://') or path.startswith('https://'):
            return ImageValidationResult(False, None, "External URLs forbidden")
        
        # Check extension
        ext = os.path.splitext(path)[1].lower()
        if ext not in self.VALID_EXTENSIONS:
            return ImageValidationResult(False, None, f"Invalid extension: {ext}")
        
        # Check exists
        local_path = os.path.join(self.IMAGES_DIR, os.path.basename(path))
        if os.path.exists(local_path):
            return ImageValidationResult(True, f"/static/images/{os.path.basename(path)}", "Valid")
        
        return ImageValidationResult(False, None, "File not found")
    
    def _normalize_name(self, name: str) -> str:
        normalized = name.lower().strip()
        normalized = re.sub(r'\d+\s*(mg|ml|mcg|g|iu|%)', '', normalized)
        for form in ['tablet', 'capsule', 'syrup', 'cream']:
            normalized = re.sub(rf'\b{form}\b', '', normalized)
        return '_'.join(normalized.split())
    
    def _find_image(self, normalized_name: str) -> Optional[str]:
        if not os.path.exists(self.IMAGES_DIR):
            return None
        
        for ext in self.VALID_EXTENSIONS:
            path = os.path.join(self.IMAGES_DIR, f"{normalized_name}{ext}")
            if os.path.exists(path):
                return f"/static/images/{normalized_name}{ext}"
        
        # Partial match
        for filename in os.listdir(self.IMAGES_DIR):
            name_part = os.path.splitext(filename)[0].lower()
            ext = os.path.splitext(filename)[1].lower()
            if ext in self.VALID_EXTENSIONS:
                if name_part.startswith(normalized_name) or normalized_name.startswith(name_part):
                    return f"/static/images/{filename}"
        return None
```

### 4.5 Create `agent/wikipedia_crawler.py`

```python
"""
Wikipedia Crawler - TEXT ONLY, No Images
"""
import re
import aiohttp
from typing import Optional, Dict, List
from urllib.parse import quote


class WikipediaCrawler:
    """
    RULES:
    1. TEXT ONLY - No images, tables, infoboxes
    2. Fetch ONLY: indications, usage, side effects
    3. Sanitize all queries
    """
    
    SEARCH_URL = "https://en.wikipedia.org/w/api.php"
    
    BLOCKED_TERMS = [
        'image', 'picture', 'photo', 'anatomy', 'diagram', 'structure',
        'illustration', 'human body', 'sexual', 'nude'
    ]
    
    def __init__(self):
        self.session = None
    
    async def _get_session(self) -> aiohttp.ClientSession:
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession(
                headers={"User-Agent": "MedicalRAGAgent/1.0"}
            )
        return self.session
    
    def sanitize_query(self, query: str) -> Optional[str]:
        """Sanitize query - block forbidden terms"""
        if not query or len(query) < 3:
            return None
        
        query_lower = query.lower()
        for term in self.BLOCKED_TERMS:
            if term in query_lower:
                return None
        
        return query
    
    async def search(self, query: str, limit: int = 3) -> List[Dict]:
        """Search Wikipedia - TEXT ONLY"""
        sanitized = self.sanitize_query(query)
        if not sanitized:
            return []
        
        session = await self._get_session()
        params = {
            "action": "query",
            "list": "search",
            "srsearch": sanitized,
            "srlimit": limit,
            "format": "json"
        }
        
        try:
            async with session.get(self.SEARCH_URL, params=params) as response:
                if response.status != 200:
                    return []
                data = await response.json()
                return [
                    {"title": item.get("title", ""), "pageid": item.get("pageid")}
                    for item in data.get("query", {}).get("search", [])
                ]
        except:
            return []
    
    async def fetch_article(self, title: str) -> Optional[str]:
        """Fetch article as PLAIN TEXT only"""
        if not title:
            return None
        
        session = await self._get_session()
        params = {
            "action": "query",
            "titles": title,
            "prop": "extracts",
            "explaintext": True,  # PLAIN TEXT ONLY
            "format": "json"
        }
        
        try:
            async with session.get(self.SEARCH_URL, params=params) as response:
                if response.status != 200:
                    return None
                
                data = await response.json()
                pages = data.get("query", {}).get("pages", {})
                
                for page_id, page_data in pages.items():
                    if page_id == "-1":
                        return None
                    extract = page_data.get("extract", "")
                    return self._clean_content(extract)
                return None
        except:
            return None
    
    def _clean_content(self, text: str) -> str:
        """Remove URLs and image references"""
        if not text:
            return ""
        text = re.sub(r'https?://[^\s]+', '', text)
        text = re.sub(r'\S+\.(jpg|jpeg|png|gif|svg)\b', '', text, flags=re.IGNORECASE)
        text = re.sub(r'\[\d+\]', '', text)
        return text.strip()
    
    async def close(self):
        if self.session and not self.session.closed:
            await self.session.close()
```

### 4.6 Create `agent/database.py`

```python
"""
Medication Database - SQLite with LOCAL images only
"""
import os
import sqlite3
from pathlib import Path
from typing import Dict, List, Optional, Any
from contextlib import contextmanager


class MedicationDatabase:
    """
    RULES:
    1. DB lookup ALWAYS before web crawling
    2. Images ONLY from /static/images/
    """
    
    DB_PATH = "data/medications.db"
    IMAGES_DIR = "static/images"
    
    def __init__(self):
        Path("data").mkdir(exist_ok=True)
        Path(self.IMAGES_DIR).mkdir(parents=True, exist_ok=True)
    
    @contextmanager
    def _connection(self):
        conn = sqlite3.connect(self.DB_PATH)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
        finally:
            conn.close()
    
    def initialize(self):
        """Create tables and insert sample data"""
        with self._connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS medications (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL UNIQUE,
                    price REAL DEFAULT 0.0,
                    manufacturer TEXT,
                    ingredients TEXT,
                    form TEXT,
                    size TEXT,
                    prescription_required INTEGER DEFAULT 0,
                    description TEXT,
                    image TEXT,
                    synonyms TEXT
                )
            ''')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_name ON medications(name)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_ingredients ON medications(ingredients)')
            conn.commit()
            
            cursor.execute("SELECT COUNT(*) FROM medications")
            if cursor.fetchone()[0] == 0:
                self._insert_sample_data(conn)
    
    def _insert_sample_data(self, conn):
        """Insert sample medications"""
        samples = [
            ("panadol", 5.99, "GSK", "paracetamol", "tablet", "500mg", 0, 
             "Pain reliever and fever reducer", "panadol.jpg", "panadol extra,acetaminophen"),
            ("amoxicillin", 12.50, "Various", "amoxicillin trihydrate", "capsule", "500mg", 1,
             "Broad-spectrum antibiotic", "amoxicillin.png", "amoxil,trimox"),
            ("ibuprofen", 7.99, "Various", "ibuprofen", "tablet", "400mg", 0,
             "NSAID for pain and inflammation", "ibuprofen.jpg", "advil,motrin"),
            ("cetirizine", 8.50, "Various", "cetirizine hydrochloride", "tablet", "10mg", 0,
             "Antihistamine for allergies", "cetirizine.jpg", "zyrtec"),
            ("omeprazole", 15.00, "Various", "omeprazole", "capsule", "20mg", 0,
             "PPI for acid reflux", "omeprazole.jpg", "prilosec"),
            ("aspirin", 4.50, "Bayer", "acetylsalicylic acid", "tablet", "325mg", 0,
             "Pain reliever and blood thinner", "aspirin.jpg", "bayer aspirin"),
        ]
        
        cursor = conn.cursor()
        for med in samples:
            cursor.execute('''
                INSERT INTO medications 
                (name, price, manufacturer, ingredients, form, size, 
                 prescription_required, description, image, synonyms)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', med)
        conn.commit()
    
    def search(self, query: str, limit: int = 10) -> List[Dict]:
        """Search with multiple strategies"""
        query = query.lower().strip()
        
        with self._connection() as conn:
            cursor = conn.cursor()
            
            # Exact match
            cursor.execute("SELECT * FROM medications WHERE LOWER(name) = ?", (query,))
            exact = cursor.fetchall()
            if exact:
                return [self._row_to_dict(r) for r in exact]
            
            results = []
            
            # Partial match
            cursor.execute(
                "SELECT * FROM medications WHERE LOWER(name) LIKE ? LIMIT ?",
                (f"%{query}%", limit)
            )
            results.extend(cursor.fetchall())
            
            # Ingredient match
            if len(results) < limit:
                cursor.execute(
                    "SELECT * FROM medications WHERE LOWER(ingredients) LIKE ? LIMIT ?",
                    (f"%{query}%", limit - len(results))
                )
                results.extend(cursor.fetchall())
            
            # Synonym match
            if len(results) < limit:
                cursor.execute(
                    "SELECT * FROM medications WHERE LOWER(synonyms) LIKE ? LIMIT ?",
                    (f"%{query}%", limit - len(results))
                )
                results.extend(cursor.fetchall())
        
        # Deduplicate
        seen = set()
        unique = []
        for r in results:
            if r['id'] not in seen:
                seen.add(r['id'])
                unique.append(self._row_to_dict(r))
        return unique[:limit]
    
    def search_by_ingredient(self, ingredient: str) -> List[Dict]:
        with self._connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT * FROM medications WHERE LOWER(ingredients) LIKE ?",
                (f"%{ingredient.lower()}%",)
            )
            return [self._row_to_dict(r) for r in cursor.fetchall()]
    
    def get_all(self) -> List[Dict]:
        with self._connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM medications ORDER BY name")
            return [self._row_to_dict(r) for r in cursor.fetchall()]
    
    def count(self) -> int:
        with self._connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM medications")
            return cursor.fetchone()[0]
    
    def add(self, medication: Dict) -> int:
        with self._connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO medications 
                (name, price, manufacturer, ingredients, form, size,
                 prescription_required, description, image, synonyms)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                medication.get("name", "").lower(),
                medication.get("price", 0.0),
                medication.get("manufacturer", ""),
                medication.get("ingredients", ""),
                medication.get("form", ""),
                medication.get("size", ""),
                medication.get("prescription_required", False),
                medication.get("description", ""),
                medication.get("image", ""),
                medication.get("synonyms", "")
            ))
            conn.commit()
            return cursor.lastrowid
    
    def _row_to_dict(self, row) -> Dict:
        data = dict(row)
        # Validate image path
        if data.get("image"):
            image_name = os.path.basename(data["image"])
            image_path = os.path.join(self.IMAGES_DIR, image_name)
            if os.path.exists(image_path):
                data["image"] = f"/static/images/{image_name}"
            else:
                data["image"] = None
        return data
```

### 4.7 Create `agent/rag_engine.py`

```python
"""
Medical RAG Engine - Main Orchestrator
"""
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict

from .gemini_client import GeminiClient
from .query_classifier import QueryClassifier, QueryType, QueryIntent, ClassifiedQuery
from .database import MedicationDatabase
from .wikipedia_crawler import WikipediaCrawler
from .image_validator import ImageValidator


@dataclass
class RAGResponse:
    success: bool
    query_type: str
    extracted_keyword: str
    medications: List[Dict]
    wiki_info: Optional[str]
    message: str
    image_paths: List[str]
    
    def to_dict(self) -> Dict:
        return asdict(self)


class MedicalRAGEngine:
    """
    PROCESSING RULES (NON-NEGOTIABLE):
    1. DB lookup ALWAYS FIRST
    2. Wikipedia ONLY if medication NOT in DB AND user asks for explanation
    3. Images ONLY from local /static/images/
    4. Never hallucinate medications
    """
    
    def __init__(self, gemini_client, query_classifier, medication_db, wiki_crawler, image_validator):
        self.gemini = gemini_client
        self.classifier = query_classifier
        self.db = medication_db
        self.wiki = wiki_crawler
        self.image_validator = image_validator
    
    async def process_query(self, query: str, include_wiki: bool = False) -> RAGResponse:
        """Main processing pipeline"""
        
        # Step 1: Classify
        classification = await self.classifier.classify(query)
        
        # Validate
        if not self.classifier.validate_medical_term(classification.extracted_keyword):
            return RAGResponse(
                success=False,
                query_type=classification.query_type.value,
                extracted_keyword=classification.extracted_keyword,
                medications=[],
                wiki_info=None,
                message="Invalid query detected.",
                image_paths=[]
            )
        
        # Step 2: Route by type
        if classification.query_type == QueryType.MEDICATION:
            return await self._handle_medication(classification, include_wiki)
        elif classification.query_type in [QueryType.DISEASE, QueryType.SYMPTOM]:
            return await self._handle_disease(classification, include_wiki)
        else:
            return await self._handle_general(classification, include_wiki)
    
    async def _handle_medication(self, classification: ClassifiedQuery, include_wiki: bool) -> RAGResponse:
        """Handle medication queries - DB FIRST"""
        medications = self.db.search(classification.normalized_keyword)
        
        if medications:
            image_paths = []
            for med in medications:
                result = self.image_validator.validate(med.get('name', ''))
                if result.is_valid:
                    med['image'] = result.path
                    image_paths.append(result.path)
                else:
                    med['image'] = None
            
            wiki_info = None
            if include_wiki and classification.requires_wiki:
                wiki_info = await self._fetch_wiki(classification.extracted_keyword, "medication")
            
            return RAGResponse(
                success=True,
                query_type=classification.query_type.value,
                extracted_keyword=classification.extracted_keyword,
                medications=medications,
                wiki_info=wiki_info,
                message=f"Found {len(medications)} medication(s)",
                image_paths=image_paths
            )
        
        # Not found - suggest alternatives
        all_meds = self.db.get_all()
        suggestions = [m['name'] for m in all_meds if classification.normalized_keyword[:3] in m['name']][:3]
        
        return RAGResponse(
            success=False,
            query_type=classification.query_type.value,
            extracted_keyword=classification.extracted_keyword,
            medications=[],
            wiki_info=None,
            message=f"Not found. Did you mean: {', '.join(suggestions)}?" if suggestions else "Not found.",
            image_paths=[]
        )
    
    async def _handle_disease(self, classification: ClassifiedQuery, include_wiki: bool) -> RAGResponse:
        """Handle disease/symptom - map to medications via Gemini"""
        ingredients = await self.gemini.map_disease_to_medications(classification.extracted_keyword)
        
        all_medications = []
        seen_ids = set()
        
        for ingredient in ingredients:
            meds = self.db.search_by_ingredient(ingredient)
            for med in meds:
                if med['id'] not in seen_ids:
                    seen_ids.add(med['id'])
                    result = self.image_validator.validate(med.get('name', ''))
                    med['image'] = result.path if result.is_valid else None
                    med['matched_ingredient'] = ingredient
                    all_medications.append(med)
        
        image_paths = [m['image'] for m in all_medications if m['image']]
        
        wiki_info = None
        if include_wiki or classification.requires_wiki:
            wiki_info = await self._fetch_wiki(classification.extracted_keyword, "disease")
        
        if all_medications:
            return RAGResponse(
                success=True,
                query_type=classification.query_type.value,
                extracted_keyword=classification.extracted_keyword,
                medications=all_medications,
                wiki_info=wiki_info,
                message=f"Found {len(all_medications)} medication(s) for '{classification.extracted_keyword}'",
                image_paths=image_paths
            )
        
        return RAGResponse(
            success=wiki_info is not None,
            query_type=classification.query_type.value,
            extracted_keyword=classification.extracted_keyword,
            medications=[],
            wiki_info=wiki_info,
            message="No medications found. Consult a healthcare provider.",
            image_paths=[]
        )
    
    async def _handle_general(self, classification: ClassifiedQuery, include_wiki: bool) -> RAGResponse:
        """Handle general queries"""
        medications = self.db.search(classification.normalized_keyword)
        
        if medications:
            return await self._handle_medication(classification, include_wiki)
        
        wiki_info = None
        if include_wiki:
            wiki_info = await self._fetch_wiki(classification.extracted_keyword, "general")
        
        return RAGResponse(
            success=wiki_info is not None,
            query_type=classification.query_type.value,
            extracted_keyword=classification.extracted_keyword,
            medications=[],
            wiki_info=wiki_info,
            message="Could not identify medication or condition.",
            image_paths=[]
        )
    
    async def _fetch_wiki(self, keyword: str, query_type: str) -> Optional[str]:
        """Safely fetch Wikipedia - TEXT ONLY"""
        wiki_query = await self.gemini.generate_wiki_query(keyword, query_type)
        results = await self.wiki.search(wiki_query, limit=1)
        
        if not results:
            return None
        
        title = results[0].get('title')
        content = await self.wiki.fetch_article(title)
        
        if not content:
            return None
        
        return await self.gemini.summarize_wiki_content(content, keyword)
```

---

## 🚀 STEP 5: Update Your Main App (`main.py`)

Replace or update your main.py:

```python
"""
Medical RAG Agent - Main Application
"""
import os
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from fastapi import Request
from pydantic import BaseModel
from typing import Dict, List, Any, Optional

from agent import (
    GeminiClient, QueryClassifier, MedicationDatabase,
    WikipediaCrawler, ImageValidator, MedicalRAGEngine
)

# Initialize components
gemini = GeminiClient()
classifier = QueryClassifier(gemini)
db = MedicationDatabase()
wiki = WikipediaCrawler()
image_validator = ImageValidator()
rag_engine = MedicalRAGEngine(gemini, classifier, db, wiki, image_validator)


@asynccontextmanager
async def lifespan(app: FastAPI):
    print("🏥 Starting Medical RAG Agent...")
    db.initialize()
    yield
    print("👋 Shutting down...")
    await wiki.close()


app = FastAPI(title="Medical RAG Agent", lifespan=lifespan)
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


class QueryRequest(BaseModel):
    query: str
    include_wiki: bool = False


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/health")
async def health():
    return {
        "status": "healthy",
        "database_count": db.count(),
        "gemini_connected": gemini.is_connected()
    }


@app.post("/query")
async def query(request: QueryRequest):
    """Main query endpoint"""
    try:
        result = await rag_engine.process_query(request.query, request.include_wiki)
        return result.to_dict()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/medications")
async def list_medications():
    return db.get_all()


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
```

---

## 📸 STEP 6: Add Medication Images

Place your medication images in `static/images/`:

```
static/images/
├── panadol.jpg
├── amoxicillin.png
├── ibuprofen.jpg
├── cetirizine.jpg
├── omeprazole.jpg
└── aspirin.jpg
```

**CRITICAL**: Only local images are allowed!

---

## ✅ STEP 7: Test Your Integration

1. **Start the server**:
   ```bash
   python main.py
   ```

2. **Test endpoints**:
   - `GET /` - Web interface
   - `GET /health` - System status
   - `POST /query` - Main search
   - `GET /medications` - List all meds

3. **Test queries**:
   ```bash
   curl -X POST http://localhost:8000/query \
     -H "Content-Type: application/json" \
     -d '{"query": "panadol 500mg", "include_wiki": false}'
   ```

---

## 🔒 SAFETY RULES SUMMARY

| Rule | Description |
|------|-------------|
| ✅ DB First | Always search database before any web crawling |
| ✅ Local Images Only | Images from `/static/images/` folder ONLY |
| ✅ Wikipedia Text Only | No images, tables, or media from Wikipedia |
| ✅ Gemini Validation | All medical logic validated through LLM |
| ❌ No External URLs | Block all external image URLs |
| ❌ No Hallucination | Never make up medications |
| ❌ No Disease Images | Never fetch disease/anatomy images |

---

## 🆘 Troubleshooting

1. **Gemini not connecting**: Check `GEMINI_API_KEY` in Secrets
2. **Images not showing**: Verify files exist in `static/images/`
3. **Database empty**: Delete `data/medications.db` and restart
4. **Import errors**: Ensure all files in `agent/` folder with `__init__.py`

---

## 📞 Need Help?

If you encounter issues:
1. Check Replit console for errors
2. Verify all dependencies installed
3. Ensure correct file structure
4. Test Gemini API key separately
