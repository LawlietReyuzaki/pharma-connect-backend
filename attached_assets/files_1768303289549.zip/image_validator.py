"""
Image Validator Module
Strict validation for medication images - LOCAL ONLY
"""

import os
import re
from pathlib import Path
from typing import Optional, List, Set
from dataclasses import dataclass


@dataclass
class ImageValidationResult:
    """Result of image validation"""
    is_valid: bool
    path: Optional[str]
    reason: str


class ImageValidator:
    """
    Image Validation Middleware
    
    RULES (NON-NEGOTIABLE):
    1. Images allowed ONLY from /static/images/{normalized_name}.{ext}
    2. Valid extensions: jpg, jpeg, png, gif, webp
    3. ABSOLUTELY FORBIDDEN:
       - Wikipedia images
       - Disease images
       - Anatomy diagrams
       - Chemical structures
       - Logos
       - External URLs
       - Auto-generated images
    """
    
    IMAGES_DIR = "static/images"
    VALID_EXTENSIONS: Set[str] = {'.jpg', '.jpeg', '.png', '.gif', '.webp'}
    
    # Patterns that indicate forbidden image types
    FORBIDDEN_PATTERNS = [
        r'wikipedia',
        r'wikimedia',
        r'anatomy',
        r'diagram',
        r'structure',
        r'chemical',
        r'molecule',
        r'logo',
        r'icon',
        r'disease',
        r'symptom',
        r'http[s]?://',
        r'www\.',
        r'\.com/',
        r'\.org/',
        r'upload\.',
    ]
    
    def __init__(self):
        self._ensure_images_dir()
        self._image_cache: dict[str, Optional[str]] = {}
    
    def _ensure_images_dir(self):
        """Ensure images directory exists"""
        Path(self.IMAGES_DIR).mkdir(parents=True, exist_ok=True)
    
    def validate(self, medication_name: str) -> ImageValidationResult:
        """
        Validate and get image path for medication
        
        Args:
            medication_name: Name of medication (will be normalized)
            
        Returns:
            ImageValidationResult with validation status and path
        """
        if not medication_name:
            return ImageValidationResult(
                is_valid=False,
                path=None,
                reason="No medication name provided"
            )
        
        # Normalize medication name
        normalized = self._normalize_name(medication_name)
        
        # Check cache first
        if normalized in self._image_cache:
            cached_path = self._image_cache[normalized]
            if cached_path:
                return ImageValidationResult(
                    is_valid=True,
                    path=cached_path,
                    reason="Found in cache"
                )
            return ImageValidationResult(
                is_valid=False,
                path=None,
                reason="Not found (cached)"
            )
        
        # Search for image file
        image_path = self._find_image(normalized)
        
        # Cache result
        self._image_cache[normalized] = image_path
        
        if image_path:
            return ImageValidationResult(
                is_valid=True,
                path=image_path,
                reason="Valid local image found"
            )
        
        return ImageValidationResult(
            is_valid=False,
            path=None,
            reason=f"No image found for: {normalized}"
        )
    
    def validate_path(self, path: str) -> ImageValidationResult:
        """
        Validate a given image path
        
        Ensures path is:
        1. Local (no external URLs)
        2. In allowed directory
        3. Has valid extension
        4. Actually exists
        """
        if not path:
            return ImageValidationResult(
                is_valid=False,
                path=None,
                reason="Empty path"
            )
        
        # Check for forbidden patterns (external URLs, etc.)
        path_lower = path.lower()
        for pattern in self.FORBIDDEN_PATTERNS:
            if re.search(pattern, path_lower):
                return ImageValidationResult(
                    is_valid=False,
                    path=None,
                    reason=f"Forbidden pattern detected: {pattern}"
                )
        
        # Must be local path
        if path.startswith('http://') or path.startswith('https://'):
            return ImageValidationResult(
                is_valid=False,
                path=None,
                reason="External URLs not allowed"
            )
        
        # Normalize to local path
        if path.startswith('/static/images/'):
            local_path = path.replace('/static/images/', f'{self.IMAGES_DIR}/')
        elif path.startswith('static/images/'):
            local_path = path
        else:
            # Assume just filename
            local_path = os.path.join(self.IMAGES_DIR, os.path.basename(path))
        
        # Check extension
        ext = os.path.splitext(local_path)[1].lower()
        if ext not in self.VALID_EXTENSIONS:
            return ImageValidationResult(
                is_valid=False,
                path=None,
                reason=f"Invalid extension: {ext}"
            )
        
        # Check if file exists
        if os.path.exists(local_path):
            # Return web-accessible path
            web_path = f"/static/images/{os.path.basename(local_path)}"
            return ImageValidationResult(
                is_valid=True,
                path=web_path,
                reason="Valid local image"
            )
        
        return ImageValidationResult(
            is_valid=False,
            path=None,
            reason=f"File not found: {local_path}"
        )
    
    def get_all_available_images(self) -> List[str]:
        """Get list of all available medication images"""
        images = []
        
        if not os.path.exists(self.IMAGES_DIR):
            return images
        
        for filename in os.listdir(self.IMAGES_DIR):
            ext = os.path.splitext(filename)[1].lower()
            if ext in self.VALID_EXTENSIONS:
                images.append(filename)
        
        return sorted(images)
    
    def _normalize_name(self, name: str) -> str:
        """
        Normalize medication name for image lookup
        
        Rules:
        - Lowercase
        - Remove dosage (mg, ml, etc.)
        - Remove form (tablet, capsule, etc.)
        - Remove special characters
        """
        if not name:
            return ""
        
        normalized = name.lower().strip()
        
        # Remove dosage patterns
        normalized = re.sub(r'\d+\s*(mg|ml|mcg|g|iu|%)', '', normalized)
        
        # Remove form words
        forms = ['tablet', 'tablets', 'capsule', 'capsules', 'syrup', 
                'injection', 'cream', 'ointment', 'drops', 'suspension',
                'solution', 'powder', 'gel', 'patch', 'spray']
        for form in forms:
            normalized = re.sub(rf'\b{form}\b', '', normalized)
        
        # Remove special characters (keep alphanumeric and hyphen)
        normalized = re.sub(r'[^\w\s-]', '', normalized)
        
        # Clean whitespace
        normalized = '_'.join(normalized.split())
        
        return normalized
    
    def _find_image(self, normalized_name: str) -> Optional[str]:
        """
        Find image file for normalized medication name
        
        Search order:
        1. Exact match: {name}.{ext}
        2. Partial match: starts with {name}
        """
        if not os.path.exists(self.IMAGES_DIR):
            return None
        
        # Try exact match first
        for ext in self.VALID_EXTENSIONS:
            exact_path = os.path.join(self.IMAGES_DIR, f"{normalized_name}{ext}")
            if os.path.exists(exact_path):
                return f"/static/images/{normalized_name}{ext}"
        
        # Try partial match
        for filename in os.listdir(self.IMAGES_DIR):
            name_part = os.path.splitext(filename)[0].lower()
            ext = os.path.splitext(filename)[1].lower()
            
            if ext in self.VALID_EXTENSIONS:
                if name_part.startswith(normalized_name) or normalized_name.startswith(name_part):
                    return f"/static/images/{filename}"
        
        return None
    
    def block_external_image(self, url: str) -> bool:
        """
        Check if URL should be blocked
        
        Returns True if URL is external/forbidden
        """
        if not url:
            return True
        
        url_lower = url.lower()
        
        # Block all external URLs
        if url_lower.startswith('http://') or url_lower.startswith('https://'):
            return True
        
        # Block forbidden patterns
        for pattern in self.FORBIDDEN_PATTERNS:
            if re.search(pattern, url_lower):
                return True
        
        return False
    
    def clear_cache(self):
        """Clear the image cache"""
        self._image_cache.clear()
