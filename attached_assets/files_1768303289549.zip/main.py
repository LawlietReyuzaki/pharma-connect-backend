"""
Medical RAG Agent - Main Application
Intelligent Medical Web Crawling & RAG System powered by Gemini LLM
"""

import os
import json
import re
from pathlib import Path
from typing import Optional, Dict, List, Any
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel
import uvicorn

from agent.query_classifier import QueryClassifier
from agent.database import MedicationDatabase
from agent.wikipedia_crawler import WikipediaCrawler
from agent.gemini_client import GeminiClient
from agent.image_validator import ImageValidator
from agent.rag_engine import MedicalRAGEngine

# Initialize components
gemini_client = GeminiClient()
query_classifier = QueryClassifier(gemini_client)
medication_db = MedicationDatabase()
wiki_crawler = WikipediaCrawler()
image_validator = ImageValidator()
rag_engine = MedicalRAGEngine(
    gemini_client=gemini_client,
    query_classifier=query_classifier,
    medication_db=medication_db,
    wiki_crawler=wiki_crawler,
    image_validator=image_validator
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifecycle management"""
    print("🏥 Medical RAG Agent Starting...")
    medication_db.initialize()
    print("✅ Database initialized")
    yield
    print("👋 Medical RAG Agent Shutting Down...")


app = FastAPI(
    title="Medical RAG Agent",
    description="Intelligent Medical Information System with Safe RAG",
    version="1.0.0",
    lifespan=lifespan
)

# Mount static files for images
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


# Request/Response Models
class QueryRequest(BaseModel):
    query: str
    include_wiki: bool = False


class MedicationResponse(BaseModel):
    success: bool
    query_type: str
    extracted_keyword: str
    medications: List[Dict[str, Any]]
    wiki_info: Optional[str] = None
    message: str
    image_paths: List[str]


class HealthResponse(BaseModel):
    status: str
    database_count: int
    gemini_status: str


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    """Render home page"""
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    return HealthResponse(
        status="healthy",
        database_count=medication_db.count(),
        gemini_status="connected" if gemini_client.is_connected() else "disconnected"
    )


@app.post("/query", response_model=MedicationResponse)
async def process_query(request: QueryRequest):
    """
    Main query endpoint - processes medical queries through RAG pipeline
    
    Safety Rules (NON-NEGOTIABLE):
    1. Database lookup ALWAYS happens first
    2. Images ONLY from local /static/images/ folder
    3. Wikipedia TEXT ONLY (no images)
    4. Never hallucinate medications
    """
    try:
        result = await rag_engine.process_query(
            query=request.query,
            include_wiki=request.include_wiki
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/medications", response_model=List[Dict])
async def list_medications():
    """List all medications in database"""
    return medication_db.get_all()


@app.get("/medication/{name}")
async def get_medication(name: str):
    """Get specific medication by name"""
    result = medication_db.search(name)
    if not result:
        raise HTTPException(status_code=404, detail="Medication not found")
    return result


@app.post("/admin/add-medication")
async def add_medication(medication: Dict):
    """Admin endpoint to add new medication"""
    try:
        medication_db.add(medication)
        return {"success": True, "message": "Medication added"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
