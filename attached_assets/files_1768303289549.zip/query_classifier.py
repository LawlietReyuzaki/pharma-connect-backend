"""
Query Classifier Module
Classifies and processes medical queries using Gemini LLM
"""

import re
from typing import Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum


class QueryType(Enum):
    MEDICATION = "medication"
    DISEASE = "disease"
    SYMPTOM = "symptom"
    GENERAL = "general"


class QueryIntent(Enum):
    LOOKUP = "lookup"
    EXPLANATION = "explanation"
    TREATMENT = "treatment"
    SIDE_EFFECTS = "side_effects"
    DOSAGE = "dosage"


@dataclass
class ClassifiedQuery:
    """Structured classification result"""
    original_query: str
    extracted_keyword: str
    query_type: QueryType
    intent: QueryIntent
    confidence: float
    normalized_keyword: str
    requires_wiki: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "original_query": self.original_query,
            "extracted_keyword": self.extracted_keyword,
            "query_type": self.query_type.value,
            "intent": self.intent.value,
            "confidence": self.confidence,
            "normalized_keyword": self.normalized_keyword,
            "requires_wiki": self.requires_wiki
        }


class QueryClassifier:
    """
    Intelligent Query Classifier
    
    Uses Gemini LLM to:
    1. Extract medical keywords
    2. Classify query type
    3. Determine intent
    4. Normalize medication names
    """
    
    def __init__(self, gemini_client):
        self.gemini = gemini_client
    
    async def classify(self, query: str) -> ClassifiedQuery:
        """
        Main classification method
        
        Steps:
        1. Extract keyword using Gemini
        2. Normalize the keyword
        3. Determine query type and intent
        4. Check if Wikipedia is needed
        """
        # Step 1: Extract keyword using Gemini
        extraction = await self.gemini.extract_medical_keyword(query)
        
        keyword = extraction.get("extracted_keyword", "")
        query_type_str = extraction.get("query_type", "general")
        intent_str = extraction.get("intent", "lookup")
        confidence = extraction.get("confidence", 0.5)
        
        # Step 2: Normalize the keyword
        normalized = self.normalize_medication_name(keyword)
        
        # Step 3: Map to enums
        query_type = self._map_query_type(query_type_str)
        intent = self._map_intent(intent_str)
        
        # Step 4: Determine if Wikipedia is needed
        requires_wiki = self._should_fetch_wiki(query_type, intent, query)
        
        return ClassifiedQuery(
            original_query=query,
            extracted_keyword=keyword,
            query_type=query_type,
            intent=intent,
            confidence=confidence,
            normalized_keyword=normalized,
            requires_wiki=requires_wiki
        )
    
    def normalize_medication_name(self, name: str) -> str:
        """
        Normalize medication name for database lookup
        
        Rules:
        - Lowercase
        - Remove mg/ml units
        - Remove special characters
        - Strip whitespace
        
        Examples:
            "Panadol 500mg" → "panadol"
            "Amoxicillin Capsule" → "amoxicillin"
        """
        if not name:
            return ""
        
        # Lowercase
        normalized = name.lower().strip()
        
        # Remove dosage patterns (500mg, 250ml, etc.)
        normalized = re.sub(r'\d+\s*(mg|ml|mcg|g|iu|%)', '', normalized)
        
        # Remove form words
        form_words = ['tablet', 'capsule', 'syrup', 'injection', 'cream', 
                      'ointment', 'drops', 'suspension', 'solution']
        for word in form_words:
            normalized = normalized.replace(word, '')
        
        # Remove special characters except hyphen
        normalized = re.sub(r'[^\w\s-]', '', normalized)
        
        # Clean up whitespace
        normalized = ' '.join(normalized.split())
        
        return normalized.strip()
    
    def extract_dosage(self, query: str) -> Optional[str]:
        """Extract dosage information from query"""
        pattern = r'(\d+)\s*(mg|ml|mcg|g|iu)'
        match = re.search(pattern, query.lower())
        if match:
            return f"{match.group(1)}{match.group(2)}"
        return None
    
    def _map_query_type(self, type_str: str) -> QueryType:
        """Map string to QueryType enum"""
        mapping = {
            "medication": QueryType.MEDICATION,
            "disease": QueryType.DISEASE,
            "symptom": QueryType.SYMPTOM,
            "general": QueryType.GENERAL
        }
        return mapping.get(type_str.lower(), QueryType.GENERAL)
    
    def _map_intent(self, intent_str: str) -> QueryIntent:
        """Map string to QueryIntent enum"""
        mapping = {
            "lookup": QueryIntent.LOOKUP,
            "explanation": QueryIntent.EXPLANATION,
            "treatment": QueryIntent.TREATMENT,
            "side_effects": QueryIntent.SIDE_EFFECTS,
            "dosage": QueryIntent.DOSAGE
        }
        return mapping.get(intent_str.lower(), QueryIntent.LOOKUP)
    
    def _should_fetch_wiki(self, query_type: QueryType, intent: QueryIntent, query: str) -> bool:
        """
        Determine if Wikipedia fetch is needed
        
        Wiki is fetched ONLY if:
        1. Medication NOT found in DB (checked later)
        2. AND user asks for explanation
        3. OR query is about disease/symptom explanation
        """
        # Disease/symptom explanation queries may need wiki
        if query_type in [QueryType.DISEASE, QueryType.SYMPTOM]:
            if intent in [QueryIntent.EXPLANATION, QueryIntent.SIDE_EFFECTS]:
                return True
        
        # Check for explicit explanation request
        explanation_keywords = ['what is', 'explain', 'tell me about', 'information about',
                               'symptoms of', 'causes of', 'side effects']
        query_lower = query.lower()
        
        return any(kw in query_lower for kw in explanation_keywords)
    
    def validate_medical_term(self, term: str) -> bool:
        """
        Basic validation that term appears to be medical
        Prevents injection of non-medical queries
        """
        # Block obvious non-medical terms
        blocked_patterns = [
            r'http[s]?://',  # URLs
            r'<.*?>',        # HTML tags
            r'[{}]',         # Code blocks
            r'SELECT|INSERT|UPDATE|DELETE',  # SQL
        ]
        
        for pattern in blocked_patterns:
            if re.search(pattern, term, re.IGNORECASE):
                return False
        
        # Must be reasonable length
        if len(term) < 2 or len(term) > 100:
            return False
        
        return True
