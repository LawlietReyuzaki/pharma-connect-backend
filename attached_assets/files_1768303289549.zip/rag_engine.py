"""
Medical RAG Engine
Main orchestrator for the Medical RAG Agent
"""

from typing import Dict, List, Any, Optional
from dataclasses import dataclass

from .gemini_client import GeminiClient
from .query_classifier import QueryClassifier, QueryType, QueryIntent, ClassifiedQuery
from .database import MedicationDatabase
from .wikipedia_crawler import WikipediaCrawler
from .image_validator import ImageValidator


@dataclass
class RAGResponse:
    """Structured RAG response"""
    success: bool
    query_type: str
    extracted_keyword: str
    medications: List[Dict[str, Any]]
    wiki_info: Optional[str]
    message: str
    image_paths: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "query_type": self.query_type,
            "extracted_keyword": self.extracted_keyword,
            "medications": self.medications,
            "wiki_info": self.wiki_info,
            "message": self.message,
            "image_paths": self.image_paths
        }


class MedicalRAGEngine:
    """
    Medical RAG Engine - Main Orchestrator
    
    PROCESSING RULES (NON-NEGOTIABLE):
    
    1. DB lookup ALWAYS happens FIRST
    2. Wikipedia ONLY if:
       - Medication NOT in DB
       - AND user asks for explanation
    3. Images ONLY from local /static/images/
    4. Never hallucinate medications
    5. Safety > completeness
    """
    
    def __init__(
        self,
        gemini_client: GeminiClient,
        query_classifier: QueryClassifier,
        medication_db: MedicationDatabase,
        wiki_crawler: WikipediaCrawler,
        image_validator: ImageValidator
    ):
        self.gemini = gemini_client
        self.classifier = query_classifier
        self.db = medication_db
        self.wiki = wiki_crawler
        self.image_validator = image_validator
    
    async def process_query(
        self,
        query: str,
        include_wiki: bool = False
    ) -> RAGResponse:
        """
        Main query processing pipeline
        
        Steps:
        1. Classify query (extract keyword, determine type)
        2. Search internal DB FIRST (mandatory)
        3. If needed, map disease → medication
        4. Optionally fetch Wikipedia (TEXT ONLY)
        5. Validate all images
        6. Return structured response
        """
        
        # Step 1: Classify the query
        classification = await self.classifier.classify(query)
        print(f"📋 Classification: {classification.to_dict()}")
        
        # Validate the extracted keyword
        if not self.classifier.validate_medical_term(classification.extracted_keyword):
            return RAGResponse(
                success=False,
                query_type=classification.query_type.value,
                extracted_keyword=classification.extracted_keyword,
                medications=[],
                wiki_info=None,
                message="Invalid or potentially unsafe query detected.",
                image_paths=[]
            )
        
        # Step 2: Route based on query type
        if classification.query_type == QueryType.MEDICATION:
            return await self._handle_medication_query(classification, include_wiki)
        
        elif classification.query_type in [QueryType.DISEASE, QueryType.SYMPTOM]:
            return await self._handle_disease_query(classification, include_wiki)
        
        else:
            return await self._handle_general_query(classification, include_wiki)
    
    async def _handle_medication_query(
        self,
        classification: ClassifiedQuery,
        include_wiki: bool
    ) -> RAGResponse:
        """
        Handle medication-specific queries
        
        Actions:
        1. Normalize name (lowercase, remove mg/ml)
        2. Search DB:
           - exact match → name
           - partial match → ingredients
           - fuzzy match → synonyms
        3. Get images from local folder ONLY
        4. If not found → suggest closest matches
        """
        
        # Search database
        medications = self.db.search(classification.normalized_keyword)
        
        if medications:
            # Validate images for each medication
            image_paths = []
            for med in medications:
                img_result = self.image_validator.validate(med.get('name', ''))
                if img_result.is_valid:
                    med['image'] = img_result.path
                    image_paths.append(img_result.path)
                else:
                    med['image'] = None
            
            # Optionally get Wikipedia info
            wiki_info = None
            if include_wiki and classification.requires_wiki:
                wiki_info = await self._fetch_wiki_safely(
                    classification.extracted_keyword,
                    "medication"
                )
            
            return RAGResponse(
                success=True,
                query_type=classification.query_type.value,
                extracted_keyword=classification.extracted_keyword,
                medications=medications,
                wiki_info=wiki_info,
                message=f"Found {len(medications)} medication(s) matching '{classification.extracted_keyword}'",
                image_paths=image_paths
            )
        
        # Not found - suggest closest matches
        all_meds = self.db.get_all()
        suggestions = self._find_similar(
            classification.normalized_keyword,
            [m['name'] for m in all_meds]
        )
        
        return RAGResponse(
            success=False,
            query_type=classification.query_type.value,
            extracted_keyword=classification.extracted_keyword,
            medications=[],
            wiki_info=None,
            message=f"Medication '{classification.extracted_keyword}' not found. "
                   f"Did you mean: {', '.join(suggestions[:3])}?" if suggestions else
                   f"Medication '{classification.extracted_keyword}' not found in database.",
            image_paths=[]
        )
    
    async def _handle_disease_query(
        self,
        classification: ClassifiedQuery,
        include_wiki: bool
    ) -> RAGResponse:
        """
        Handle disease/symptom queries
        
        Actions:
        1. Use Gemini to map: disease → ingredient → medication
        2. Suggest medications ONLY from DB
        3. If explanation needed → fetch TEXT ONLY from Wikipedia
        4. NEVER fetch disease images
        """
        
        # Map disease to medications via Gemini
        ingredients = await self.gemini.map_disease_to_medications(
            classification.extracted_keyword
        )
        print(f"💊 Mapped ingredients: {ingredients}")
        
        # Search DB for each ingredient
        all_medications = []
        seen_ids = set()
        
        for ingredient in ingredients:
            meds = self.db.search_by_ingredient(ingredient)
            for med in meds:
                if med['id'] not in seen_ids:
                    seen_ids.add(med['id'])
                    # Validate image
                    img_result = self.image_validator.validate(med.get('name', ''))
                    med['image'] = img_result.path if img_result.is_valid else None
                    med['matched_ingredient'] = ingredient
                    all_medications.append(med)
        
        # Get image paths
        image_paths = [m['image'] for m in all_medications if m['image']]
        
        # Fetch Wikipedia info if needed (TEXT ONLY!)
        wiki_info = None
        if include_wiki or classification.requires_wiki:
            wiki_info = await self._fetch_wiki_safely(
                classification.extracted_keyword,
                classification.query_type.value
            )
        
        if all_medications:
            return RAGResponse(
                success=True,
                query_type=classification.query_type.value,
                extracted_keyword=classification.extracted_keyword,
                medications=all_medications,
                wiki_info=wiki_info,
                message=f"Found {len(all_medications)} medication(s) for '{classification.extracted_keyword}'",
                image_paths=image_paths
            )
        
        # No medications found, but might have wiki info
        return RAGResponse(
            success=wiki_info is not None,
            query_type=classification.query_type.value,
            extracted_keyword=classification.extracted_keyword,
            medications=[],
            wiki_info=wiki_info,
            message=f"No specific medications found for '{classification.extracted_keyword}' in database. "
                   "Please consult a healthcare provider for treatment recommendations.",
            image_paths=[]
        )
    
    async def _handle_general_query(
        self,
        classification: ClassifiedQuery,
        include_wiki: bool
    ) -> RAGResponse:
        """Handle general/unclear queries"""
        
        # Try database search anyway
        medications = self.db.search(classification.normalized_keyword)
        
        if medications:
            return await self._handle_medication_query(classification, include_wiki)
        
        # Get Wikipedia info if requested
        wiki_info = None
        if include_wiki:
            wiki_info = await self._fetch_wiki_safely(
                classification.extracted_keyword,
                "general"
            )
        
        return RAGResponse(
            success=wiki_info is not None,
            query_type=classification.query_type.value,
            extracted_keyword=classification.extracted_keyword,
            medications=[],
            wiki_info=wiki_info,
            message="Could not identify a specific medication or condition. "
                   "Please try searching for a specific medication name or medical condition.",
            image_paths=[]
        )
    
    async def _fetch_wiki_safely(
        self,
        keyword: str,
        query_type: str
    ) -> Optional[str]:
        """
        Safely fetch Wikipedia content
        
        Rules:
        1. Generate proper search query via Gemini
        2. Sanitize query
        3. Fetch TEXT ONLY
        4. Summarize with Gemini
        """
        
        # Generate appropriate Wikipedia query
        wiki_query = await self.gemini.generate_wiki_query(keyword, query_type)
        print(f"🔍 Wiki query: {wiki_query}")
        
        # Search Wikipedia
        search_results = await self.wiki.search(wiki_query, limit=1)
        
        if not search_results:
            return None
        
        # Fetch article content
        title = search_results[0].get('title')
        content = await self.wiki.fetch_article(title)
        
        if not content:
            # Fall back to summary
            content = await self.wiki.fetch_summary(title)
        
        if not content:
            return None
        
        # Summarize with Gemini
        summary = await self.gemini.summarize_wiki_content(content, keyword)
        
        return summary
    
    def _find_similar(self, query: str, candidates: List[str], top_n: int = 5) -> List[str]:
        """Find similar strings using simple string matching"""
        if not query or not candidates:
            return []
        
        query_lower = query.lower()
        scored = []
        
        for candidate in candidates:
            cand_lower = candidate.lower()
            
            # Calculate similarity score
            score = 0
            
            # Starts with
            if cand_lower.startswith(query_lower):
                score += 100
            
            # Contains
            if query_lower in cand_lower:
                score += 50
            
            # Reverse contains
            if cand_lower in query_lower:
                score += 30
            
            # Character overlap
            common = set(query_lower) & set(cand_lower)
            score += len(common) * 2
            
            if score > 0:
                scored.append((candidate, score))
        
        # Sort by score descending
        scored.sort(key=lambda x: x[1], reverse=True)
        
        return [s[0] for s in scored[:top_n]]
