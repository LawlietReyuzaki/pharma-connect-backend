"""
Wikipedia Crawler Module
TEXT-ONLY Wikipedia content fetching with strict safety rules
"""

import re
import aiohttp
from typing import Optional, Dict, Any
from urllib.parse import quote


class WikipediaCrawler:
    """
    Safe Wikipedia Content Crawler
    
    RULES (NON-NEGOTIABLE):
    1. TEXT ONLY - No images, tables, infoboxes, media
    2. Fetch ONLY: indications, usage, side effects
    3. NEVER fetch: images, tables, infoboxes, media links
    4. Sanitize all queries before fetching
    """
    
    BASE_URL = "https://en.wikipedia.org/api/rest_v1"
    SEARCH_URL = "https://en.wikipedia.org/w/api.php"
    
    # Blocked content patterns
    BLOCKED_PATTERNS = [
        r'<img[^>]*>',           # Images
        r'<table[^>]*>.*?</table>',  # Tables
        r'class="infobox"',       # Infoboxes
        r'class="navbox"',        # Navigation boxes
        r'class="sidebar"',       # Sidebars
        r'\[\[File:.*?\]\]',      # File links
        r'\[\[Image:.*?\]\]',     # Image links
        r'thumb\|',               # Thumbnail references
        r'\.jpg|\.png|\.gif|\.svg',  # Image extensions
    ]
    
    # Blocked query terms
    BLOCKED_QUERY_TERMS = [
        'image', 'images', 'picture', 'pictures', 'photo', 'photos',
        'anatomy', 'diagram', 'structure', 'illustration',
        'human body', 'body part', 'sexual', 'nude'
    ]
    
    def __init__(self):
        self.session = None
    
    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create aiohttp session"""
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession(
                headers={"User-Agent": "MedicalRAGAgent/1.0"}
            )
        return self.session
    
    def sanitize_query(self, query: str) -> Optional[str]:
        """
        Sanitize Wikipedia query
        
        Rules:
        ✅ Allowed: "Syphilis disease symptoms"
        ❌ Blocked: "fever", "medicine images", "human anatomy"
        """
        if not query or len(query) < 3:
            return None
        
        query_lower = query.lower()
        
        # Check for blocked terms
        for term in self.BLOCKED_QUERY_TERMS:
            if term in query_lower:
                print(f"⚠️ Blocked query term detected: {term}")
                return None
        
        # Remove any image-related words
        cleaned = query
        for term in self.BLOCKED_QUERY_TERMS:
            cleaned = re.sub(rf'\b{term}\b', '', cleaned, flags=re.IGNORECASE)
        
        # Clean up whitespace
        cleaned = ' '.join(cleaned.split())
        
        if len(cleaned) < 3:
            return None
        
        return cleaned
    
    async def search(self, query: str, limit: int = 3) -> list[Dict[str, Any]]:
        """
        Search Wikipedia for relevant articles
        
        Returns list of article titles and snippets (TEXT ONLY)
        """
        sanitized = self.sanitize_query(query)
        if not sanitized:
            print(f"⚠️ Query blocked: {query}")
            return []
        
        session = await self._get_session()
        
        params = {
            "action": "query",
            "list": "search",
            "srsearch": sanitized,
            "srlimit": limit,
            "format": "json",
            "srprop": "snippet|titlesnippet"
        }
        
        try:
            async with session.get(self.SEARCH_URL, params=params) as response:
                if response.status != 200:
                    return []
                
                data = await response.json()
                results = []
                
                for item in data.get("query", {}).get("search", []):
                    # Clean snippet of any HTML
                    snippet = self._clean_html(item.get("snippet", ""))
                    
                    results.append({
                        "title": item.get("title", ""),
                        "snippet": snippet,
                        "pageid": item.get("pageid")
                    })
                
                return results
                
        except Exception as e:
            print(f"Wikipedia search error: {e}")
            return []
    
    async def fetch_article(self, title: str) -> Optional[str]:
        """
        Fetch Wikipedia article content (TEXT ONLY)
        
        Extracts ONLY:
        - Plain text content
        - Medical sections (symptoms, treatment, etc.)
        
        Ignores:
        - Images
        - Tables
        - Infoboxes
        - Media links
        """
        if not title:
            return None
        
        session = await self._get_session()
        
        # Use the TextExtracts API for plain text
        params = {
            "action": "query",
            "titles": title,
            "prop": "extracts",
            "exintro": False,  # Get full article
            "explaintext": True,  # Plain text only
            "format": "json"
        }
        
        try:
            async with session.get(self.SEARCH_URL, params=params) as response:
                if response.status != 200:
                    return None
                
                data = await response.json()
                pages = data.get("query", {}).get("pages", {})
                
                for page_id, page_data in pages.items():
                    if page_id == "-1":  # Page not found
                        return None
                    
                    extract = page_data.get("extract", "")
                    
                    # Clean and filter content
                    cleaned = self._clean_content(extract)
                    
                    # Extract medical sections
                    medical_content = self._extract_medical_sections(cleaned)
                    
                    return medical_content if medical_content else cleaned[:3000]
                
                return None
                
        except Exception as e:
            print(f"Wikipedia fetch error: {e}")
            return None
    
    async def fetch_summary(self, title: str) -> Optional[str]:
        """Fetch just the article summary/intro"""
        if not title:
            return None
        
        session = await self._get_session()
        encoded_title = quote(title.replace(" ", "_"))
        url = f"{self.BASE_URL}/page/summary/{encoded_title}"
        
        try:
            async with session.get(url) as response:
                if response.status != 200:
                    return None
                
                data = await response.json()
                
                # Get plain text extract only
                extract = data.get("extract", "")
                
                # Verify no image URLs leaked through
                extract = self._remove_urls(extract)
                
                return extract
                
        except Exception as e:
            print(f"Wikipedia summary error: {e}")
            return None
    
    def _clean_html(self, text: str) -> str:
        """Remove all HTML tags from text"""
        if not text:
            return ""
        
        # Remove HTML tags
        clean = re.sub(r'<[^>]+>', '', text)
        
        # Decode HTML entities
        clean = clean.replace("&quot;", '"')
        clean = clean.replace("&amp;", "&")
        clean = clean.replace("&lt;", "<")
        clean = clean.replace("&gt;", ">")
        clean = clean.replace("&nbsp;", " ")
        
        return clean.strip()
    
    def _clean_content(self, text: str) -> str:
        """Clean Wikipedia content of unwanted elements"""
        if not text:
            return ""
        
        # Remove blocked patterns
        for pattern in self.BLOCKED_PATTERNS:
            text = re.sub(pattern, '', text, flags=re.IGNORECASE | re.DOTALL)
        
        # Remove URLs
        text = self._remove_urls(text)
        
        # Remove reference markers [1], [2], etc.
        text = re.sub(r'\[\d+\]', '', text)
        
        # Remove edit markers
        text = re.sub(r'\[edit\]', '', text, flags=re.IGNORECASE)
        
        # Clean up excessive whitespace
        text = re.sub(r'\n{3,}', '\n\n', text)
        text = re.sub(r' {2,}', ' ', text)
        
        return text.strip()
    
    def _remove_urls(self, text: str) -> str:
        """Remove all URLs from text"""
        # Remove http/https URLs
        text = re.sub(r'https?://[^\s]+', '', text)
        
        # Remove image file references
        text = re.sub(r'\S+\.(jpg|jpeg|png|gif|svg|webp)\b', '', text, flags=re.IGNORECASE)
        
        return text
    
    def _extract_medical_sections(self, text: str) -> Optional[str]:
        """
        Extract only medically relevant sections
        
        Target sections:
        - Signs and symptoms
        - Causes
        - Treatment
        - Side effects
        - Indications
        - Contraindications
        - Pharmacology
        """
        medical_keywords = [
            'signs and symptoms', 'symptoms', 'causes', 'treatment',
            'side effects', 'adverse effects', 'indications', 'uses',
            'contraindications', 'warnings', 'pharmacology', 'mechanism',
            'dosage', 'administration', 'diagnosis', 'prevention'
        ]
        
        sections = []
        lines = text.split('\n')
        
        capturing = False
        current_section = []
        
        for line in lines:
            line_lower = line.lower().strip()
            
            # Check if this is a relevant section header
            is_medical_header = any(kw in line_lower for kw in medical_keywords)
            is_header = line.strip().endswith('==') or line.isupper() or (
                len(line) < 50 and line.strip() and not line.strip().endswith('.')
            )
            
            if is_medical_header:
                # Save previous section if exists
                if current_section:
                    sections.append('\n'.join(current_section))
                current_section = [line]
                capturing = True
            elif capturing:
                # Check if we hit a non-medical section
                if is_header and not is_medical_header:
                    if current_section:
                        sections.append('\n'.join(current_section))
                    current_section = []
                    capturing = False
                else:
                    current_section.append(line)
        
        # Don't forget last section
        if current_section:
            sections.append('\n'.join(current_section))
        
        if sections:
            return '\n\n'.join(sections)
        
        return None
    
    async def close(self):
        """Close the aiohttp session"""
        if self.session and not self.session.closed:
            await self.session.close()
